#include <iostream>
#include <iomanip>

class Clock {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor to initialize the clock with user input
    Clock(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}

    // Function to add an hour and handle overflow
    void addHour() {
        hours = (hours + 1) % 24;
    }

    // Function to add a minute and handle overflow
    void addMinute() {
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            addHour(); // Increment hours if minutes overflow
        }
    }

    // Function to add a second and handle overflow
    void addSecond() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            addMinute(); // Increment minutes if seconds overflow
        }
    }

    // Function to display the time in 12-hour and 24-hour formats
    void displayTime() const {
        // For 12-hour format
        int displayHours = hours % 12;
        if (displayHours == 0) displayHours = 12; // Convert 00:00 to 12:00
        std::string am_pm = hours < 12 ? "AM" : "PM";
        std::cout << "12-Hour Clock: " 
                  << std::setfill('0') << std::setw(2) << displayHours << ":"
                  << std::setfill('0') << std::setw(2) << minutes << ":"
                  << std::setfill('0') << std::setw(2) << seconds << " " << am_pm << std::endl;

        // For 24-hour format
        std::cout << "24-Hour Clock: "
                  << std::setfill('0') << std::setw(2) << hours << ":"
                  << std::setfill('0') << std::setw(2) << minutes << ":"
                  << std::setfill('0') << std::setw(2) << seconds << std::endl;
    }
};

int main() {
    int hours, minutes, seconds;
    std::cout << "Enter initial time (HH MM SS): ";
    std::cin >> hours >> minutes >> seconds;

    Clock clock(hours, minutes, seconds);

    char option;
    do {
        clock.displayTime();

        // Display menu according to flowchart logic
        std::cout << "Menu:\n"
                  << " 1 - Add One Hour\n"
                  << " 2 - Add One Minute\n"
                  << " 3 - Add One Second\n"
                  << " 4 - Exit\n";
        std::cout << "Choose an option: ";
        std::cin >> option;

        switch (option) {
            case '1':
                clock.addHour();
                break;
            case '2':
                clock.addMinute();
                break;
            case '3':
                clock.addSecond();
                break;
            case '4':
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid option. Please try again." << std::endl;
                break;
        }
    } while (option != '4');

    return 0;
}
